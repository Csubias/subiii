const products = {
  rebanada: [
    { name: "Gansito", price: 30, category: "gelatina" },
    { name: "Galleta Oreo", price: 30, category: "gelatina" },
    { name: "Chocolate Abuelita", price: 30, category: "gelatina" },
    { name: "Chocolate", price: 40, category: "pastel" },
    { name: "Turín", price: 40, category: "pastel" },
    { name: "Hersheys", price: 40, category: "pastel" },
    { name: "Chocolate", price: 35, category: "pay" },
    { name: "Limón", price: 35, category: "pay" },
    { name: "Vainilla", price: 25, category: "flan" },
    { name: "Napolitano Sencillo", price: 25, category: "flan" },
    { name: "Napolitano Philadelphia", price: 25, category: "flan" },
    { name: "Elote", price: 25, category: "flan" },
  ],
  charola: [
    { name: "Chocolate", price: 40 },
    { name: "Turín", price: 40 },
    { name: "Hersheys", price: 40 },
    { name: "Fresas con crema", price: 50 }
  ],
  vaso: [
    { name: "Vaso de Gelatina", price: 60 },
    { name: "Vaso de Pay", price: 70 },
  ],
};

export default products;
